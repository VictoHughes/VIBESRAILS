"""Community packs manager for vibesrails."""
