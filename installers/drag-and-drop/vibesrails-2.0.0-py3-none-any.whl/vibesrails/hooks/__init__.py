"""VibesRails hooks for Claude Code integration."""
